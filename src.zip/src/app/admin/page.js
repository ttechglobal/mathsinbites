'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'
import { BiteMarkIcon } from '@/components/BiteMarkIcon'

// ── Design tokens — dark, pro, minimal ──────────────────────────────────────
const A = {
  bg:       '#0D0B1A',
  surface:  '#13102A',
  card:     '#1A1635',
  cardHi:   '#211D42',
  border:   'rgba(165,180,252,0.1)',
  borderHi: 'rgba(165,180,252,0.25)',
  text:     '#F1F0FF',
  dim:      'rgba(165,180,252,0.55)',
  accent:   '#7C3AED',
  accentHi: '#9F67FF',
  lime:     '#A3E635',
  coral:    '#FF6B6B',
  gold:     '#FCD34D',
  cyan:     '#67E8F9',
}

const NAV_ITEMS = [
  { href: '/admin',            icon: '📊', label: 'Overview'   },
  { href: '/admin/curriculum', icon: '📚', label: 'Curriculum' },
  { href: '/admin/generate',   icon: '⚡', label: 'Generate'   },
  { href: '/admin/students',   icon: '👥', label: 'Students'   },
  { href: '/admin/analytics',  icon: '📈', label: 'Analytics'  },
  { href: '/admin/flags',      icon: '🚩', label: 'Flagged'    },
]

function StatCard({ icon, label, value, sub, color }) {
  return (
    <div style={{
      background: A.card, border: `1.5px solid ${A.border}`,
      borderRadius: 16, padding: '20px 22px',
      transition: 'border-color .2s, transform .2s',
    }}
      onMouseEnter={e => { e.currentTarget.style.borderColor = A.borderHi; e.currentTarget.style.transform = 'translateY(-2px)' }}
      onMouseLeave={e => { e.currentTarget.style.borderColor = A.border; e.currentTarget.style.transform = 'translateY(0)' }}
    >
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 14 }}>
        <div style={{ fontSize: 24 }}>{icon}</div>
        {sub && <div style={{ fontSize: 11, fontWeight: 800, color: color || A.lime, background: `${color || A.lime}15`, border: `1px solid ${color || A.lime}30`, borderRadius: 99, padding: '2px 10px' }}>{sub}</div>}
      </div>
      <div style={{ fontFamily: 'Fredoka One, cursive', fontSize: 34, color: A.text, lineHeight: 1, marginBottom: 6 }}>{value}</div>
      <div style={{ fontSize: 12, fontWeight: 800, color: A.dim, letterSpacing: .3 }}>{label}</div>
    </div>
  )
}

export default function AdminPage({ stats, recentLogs, flaggedCount }) {
  const [activeNav, setActiveNav] = useState('/admin')
  const [sideOpen,  setSideOpen]  = useState(true)

  const s = stats || { students: 0, lessons: 0, slides: 0, questions: 0 }
  const logs = recentLogs || []

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@700;800;900&family=Fredoka+One&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        html, body { height: 100%; }

        @keyframes slideUp { from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:translateY(0)} }
        @keyframes fadeIn  { from{opacity:0} to{opacity:1} }
        @keyframes shimmer { 0%{background-position:-200% center} 100%{background-position:200% center} }

        .admin-nav-item {
          display: flex; align-items: center; gap: 10px;
          padding: 9px 14px; border-radius: 10px;
          font-family: 'Nunito', sans-serif; font-size: 13px; font-weight: 800;
          color: rgba(165,180,252,0.55); text-decoration: none;
          transition: background .15s, color .15s;
          cursor: pointer;
        }
        .admin-nav-item:hover  { background: rgba(165,180,252,0.07); color: #F1F0FF; }
        .admin-nav-item.active { background: rgba(124,58,237,0.2); color: #F1F0FF; border: 1px solid rgba(124,58,237,0.3); }

        .admin-action-btn {
          display: inline-flex; align-items: center; gap: 8px;
          background: rgba(124,58,237,0.15); border: 1.5px solid rgba(124,58,237,0.35);
          border-radius: 10px; padding: 8px 16px;
          font-family: 'Nunito', sans-serif; font-size: 13px; font-weight: 800;
          color: #A5B4FC; text-decoration: none; cursor: pointer;
          transition: background .15s, border-color .15s, color .15s;
        }
        .admin-action-btn:hover { background: rgba(124,58,237,0.3); border-color: rgba(165,180,252,0.5); color: #F1F0FF; }
        .admin-action-btn.primary {
          background: linear-gradient(135deg,#7C3AED,#4C1D95); border-color: transparent; color: #fff;
          box-shadow: 0 4px 16px rgba(124,58,237,0.4);
        }
        .admin-action-btn.primary:hover { background: linear-gradient(135deg,#9F67FF,#7C3AED); }

        ::-webkit-scrollbar { width: 5px; height: 5px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: rgba(165,180,252,0.15); border-radius: 99px; }
      `}</style>

      <div style={{ display: 'flex', height: '100vh', background: A.bg, fontFamily: 'Nunito, sans-serif', color: A.text, overflow: 'hidden' }}>

        {/* ── SIDEBAR ─────────────────────────────────────────────────────── */}
        <aside style={{
          width: sideOpen ? 220 : 60,
          flexShrink: 0,
          background: A.surface,
          borderRight: `1px solid ${A.border}`,
          display: 'flex', flexDirection: 'column',
          transition: 'width .25s ease',
          overflow: 'hidden',
        }}>
          {/* Logo row */}
          <div style={{ padding: '18px 16px 14px', borderBottom: `1px solid ${A.border}`, display: 'flex', alignItems: 'center', gap: 10, flexShrink: 0 }}>
            <BiteMarkIcon size={28} />
            {sideOpen && (
              <div style={{ overflow: 'hidden' }}>
                <div style={{ fontWeight: 900, fontSize: 15, whiteSpace: 'nowrap' }}>
                  Maths<span style={{ color: A.gold }}>In</span>Bites
                </div>
                <div style={{ fontSize: 9, fontWeight: 800, color: A.dim, letterSpacing: 1.5, textTransform: 'uppercase' }}>Admin</div>
              </div>
            )}
            <button
              onClick={() => setSideOpen(v => !v)}
              style={{ marginLeft: 'auto', background: 'none', border: 'none', cursor: 'pointer', color: A.dim, fontSize: 14, padding: 4, flexShrink: 0 }}
            >{sideOpen ? '◀' : '▶'}</button>
          </div>

          {/* Nav links */}
          <nav style={{ padding: '12px 10px', flex: 1, display: 'flex', flexDirection: 'column', gap: 3 }}>
            {NAV_ITEMS.map(item => (
              <Link key={item.href} href={item.href}
                className={`admin-nav-item ${activeNav === item.href ? 'active' : ''}`}
                onClick={() => setActiveNav(item.href)}
                title={!sideOpen ? item.label : undefined}
              >
                <span style={{ fontSize: 16, flexShrink: 0 }}>{item.icon}</span>
                {sideOpen && <span style={{ whiteSpace: 'nowrap' }}>{item.label}</span>}
                {sideOpen && item.href === '/admin/flags' && flaggedCount > 0 && (
                  <span style={{ marginLeft: 'auto', background: A.coral, color: '#fff', borderRadius: 99, padding: '1px 7px', fontSize: 10, fontWeight: 900 }}>{flaggedCount}</span>
                )}
              </Link>
            ))}
          </nav>

          {/* Bottom — back to app link */}
          <div style={{ padding: '10px 10px 16px', borderTop: `1px solid ${A.border}` }}>
            <Link href="/learn" className="admin-nav-item" title={!sideOpen ? 'Back to app' : undefined}>
              <span style={{ fontSize: 16 }}>🔙</span>
              {sideOpen && <span style={{ whiteSpace: 'nowrap' }}>Back to app</span>}
            </Link>
          </div>
        </aside>

        {/* ── MAIN CONTENT ────────────────────────────────────────────────── */}
        <main style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

          {/* Top bar */}
          <div style={{
            padding: '14px 28px', borderBottom: `1px solid ${A.border}`,
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            background: A.surface, flexShrink: 0,
          }}>
            <div>
              <h1 style={{ fontFamily: 'Fredoka One, cursive', fontSize: 22, color: A.text, lineHeight: 1 }}>Admin Overview</h1>
              <div style={{ fontSize: 12, color: A.dim, fontWeight: 700, marginTop: 2 }}>
                {new Date().toLocaleDateString('en-NG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
              </div>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <Link href="/admin/generate" className="admin-action-btn primary">
                ⚡ Generate lesson
              </Link>
              <Link href="/admin/curriculum" className="admin-action-btn">
                📚 Curriculum
              </Link>
            </div>
          </div>

          {/* Scrollable body */}
          <div style={{ flex: 1, overflowY: 'auto', padding: '24px 28px', display: 'flex', flexDirection: 'column', gap: 28 }}>

            {/* Stats grid */}
            <section aria-label="Key statistics">
              <div style={{ fontSize: 11, fontWeight: 900, color: A.dim, letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 14 }}>Overview</div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 14 }}>
                <StatCard icon="👥" label="Total students"   value={s.students.toLocaleString()}  sub="active" color={A.lime}  />
                <StatCard icon="📖" label="Lessons generated" value={s.lessons.toLocaleString()}   sub={`${s.slides} slides`} color={A.cyan}  />
                <StatCard icon="🎯" label="Questions created" value={s.questions.toLocaleString()} sub="MCQ"    color={A.gold}  />
                <StatCard icon="🚩" label="Flagged items"     value={flaggedCount || 0}             sub={flaggedCount > 0 ? 'needs review' : 'all clear'} color={flaggedCount > 0 ? A.coral : A.lime} />
              </div>
            </section>

            {/* Quick actions */}
            <section>
              <div style={{ fontSize: 11, fontWeight: 900, color: A.dim, letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 14 }}>Quick Actions</div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 12 }}>
                {[
                  { href: '/admin/generate',   icon: '⚡', title: 'Generate lesson',    desc: 'Create AI-powered lesson content for any subtopic', color: A.accentHi },
                  { href: '/admin/curriculum', icon: '📚', title: 'Manage curriculum',  desc: 'Add or edit levels, terms, units, topics, subtopics', color: A.cyan },
                  { href: '/admin/students',   icon: '👥', title: 'View students',      desc: 'Browse accounts, progress, and XP data', color: A.gold },
                  { href: '/admin/analytics',  icon: '📈', title: 'Analytics',          desc: 'Completion rates, popular topics, drop-off points', color: A.lime },
                  { href: '/admin/flags',      icon: '🚩', title: 'Review flagged',     desc: 'Questions flagged by students as incorrect', color: A.coral },
                ].map(item => (
                  <Link key={item.href} href={item.href} style={{ textDecoration: 'none' }}>
                    <div style={{
                      background: A.card, border: `1.5px solid ${A.border}`, borderRadius: 14, padding: '18px 18px',
                      cursor: 'pointer', transition: 'border-color .2s, transform .2s',
                    }}
                      onMouseEnter={e => { e.currentTarget.style.borderColor = item.color + '60'; e.currentTarget.style.transform = 'translateY(-2px)' }}
                      onMouseLeave={e => { e.currentTarget.style.borderColor = A.border; e.currentTarget.style.transform = 'translateY(0)' }}
                    >
                      <div style={{ fontSize: 24, marginBottom: 10 }}>{item.icon}</div>
                      <div style={{ fontSize: 14, fontWeight: 900, color: A.text, marginBottom: 5 }}>{item.title}</div>
                      <div style={{ fontSize: 12, color: A.dim, lineHeight: 1.6, fontWeight: 700 }}>{item.desc}</div>
                      <div style={{ marginTop: 12, fontSize: 12, fontWeight: 800, color: item.color }}>Open →</div>
                    </div>
                  </Link>
                ))}
              </div>
            </section>

            {/* Recent generation logs */}
            <section>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
                <div style={{ fontSize: 11, fontWeight: 900, color: A.dim, letterSpacing: 1.5, textTransform: 'uppercase' }}>Recent Generations</div>
                <Link href="/admin/generate" style={{ fontSize: 12, fontWeight: 800, color: A.accentHi, textDecoration: 'none' }}>View all →</Link>
              </div>
              <div style={{ background: A.card, border: `1px solid ${A.border}`, borderRadius: 16, overflow: 'hidden' }}>
                {logs.length === 0 ? (
                  <div style={{ padding: '32px', textAlign: 'center', color: A.dim, fontSize: 13, fontWeight: 700 }}>
                    No lessons generated yet.{' '}
                    <Link href="/admin/generate" style={{ color: A.accentHi, fontWeight: 900 }}>Generate your first →</Link>
                  </div>
                ) : (
                  <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                    <thead>
                      <tr style={{ borderBottom: `1px solid ${A.border}` }}>
                        {['Subtopic', 'Slides', 'Questions', 'Generated', 'Status'].map(h => (
                          <th key={h} style={{ padding: '10px 16px', textAlign: 'left', fontSize: 11, fontWeight: 900, color: A.dim, letterSpacing: 1, textTransform: 'uppercase' }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {logs.map((log, i) => (
                        <tr key={i} style={{ borderBottom: i < logs.length - 1 ? `1px solid ${A.border}` : 'none', transition: 'background .15s' }}
                          onMouseEnter={e => e.currentTarget.style.background = A.cardHi}
                          onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                        >
                          <td style={{ padding: '12px 16px', fontSize: 13, fontWeight: 800, color: A.text }}>{log.subtopic_title || log.subtopic_id?.slice(0, 8) + '…'}</td>
                          <td style={{ padding: '12px 16px', fontSize: 13, color: A.dim, fontWeight: 700 }}>{log.slide_count ?? '—'}</td>
                          <td style={{ padding: '12px 16px', fontSize: 13, color: A.dim, fontWeight: 700 }}>{log.question_count ?? '—'}</td>
                          <td style={{ padding: '12px 16px', fontSize: 12, color: A.dim, fontWeight: 700 }}>
                            {log.created_at ? new Date(log.created_at).toLocaleDateString('en-NG', { day: 'numeric', month: 'short' }) : '—'}
                          </td>
                          <td style={{ padding: '12px 16px' }}>
                            <span style={{ background: `${A.lime}15`, border: `1px solid ${A.lime}30`, borderRadius: 99, padding: '3px 10px', fontSize: 11, fontWeight: 800, color: A.lime }}>
                              Done
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            </section>

          </div>
        </main>
      </div>
    </>
  )
}